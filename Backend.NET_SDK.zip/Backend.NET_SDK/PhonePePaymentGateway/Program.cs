using System.Text.Json;
using Microsoft.Extensions.Logging;
using pg_sdk_dotnet;
using pg_sdk_dotnet.Common.Models.Request;
using pg_sdk_dotnet.Common.Models.Request.PaymentModeConstraints;
using pg_sdk_dotnet.Common.Models.Response;
using pg_sdk_dotnet.Common.Utils;
using pg_sdk_dotnet.Payments.v2;
using pg_sdk_dotnet.Payments.v2.Models.Request;
using pg_sdk_dotnet.Payments.v2.Models.Response;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllers();

var app = builder.Build();

app.MapControllers();

// Step 1: Initialize the logger (to log responses from the SDK)
using ILoggerFactory loggerFactory = LoggerFactory.Create(builder =>
{
    builder.AddConsole();
});
ILogger logger = loggerFactory.CreateLogger("PhonePeSDK");

// Step 2: Get credentials from configuration
string clientId = app.Configuration["PhonePe:ClientId"] ?? throw new InvalidOperationException("ClientId not configured");
string clientSecret = app.Configuration["PhonePe:ClientSecret"] ?? throw new InvalidOperationException("ClientSecret not configured");
int clientVersion = int.Parse(app.Configuration["PhonePe:ClientVersion"] ?? "1");

// Step 3: Set environment (SANDBOX for testing, PRODUCTION for live)
Env env = Env.SANDBOX; // Change to Env.PRODUCTION when you go live

// Step 4: Initialize PhonePe StandardCheckoutClient
StandardCheckoutClient checkoutClient = StandardCheckoutClient.GetInstance(
    clientId,
    clientSecret,
    clientVersion,
    env,
    loggerFactory // null if logs do not want to be printed
);

logger.LogInformation("PhonePe SDK initialized successfully!");
logger.LogInformation("Client ID: {ClientId}", clientId);
logger.LogInformation("Environment: {Environment}", env);

// Simple test endpoint
app.MapGet("/", () => new
{
    status = "PhonePe SDK Ready",
    environment = env.ToString(),
    clientId = clientId,
    timestamp = DateTime.UtcNow
});

// Create Payment Endpoint
app.MapPost("/create-payment", async () =>
{
    try
    {
        var redirectUrl = "https://www.merchant.com/redirect";
        var merchantOrderID = Guid.NewGuid().ToString();
         
        // Build Payment Request (following PhonePe documentation)
        var payRequest = StandardCheckoutPayRequest.Builder()
                    .SetMerchantOrderId(merchantOrderID)
                    .SetAmount(100) // Amount in paise (100 paise = ₹1)
                    .SetRedirectUrl(redirectUrl)
                    .SetExpireAfter(300) // Expires in 300 seconds
                    .SetMessage("Test Payment")
                    .Build();
         
        // Call PhonePe Pay API
        StandardCheckoutPayResponse response = await checkoutClient.Pay(payRequest);
        
        // Log the response
        logger.LogInformation("Pay API Response:\n{Response}", JsonSerializer.Serialize(response, new JsonSerializerOptions 
        { 
            WriteIndented = true,
            Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        }));

        return Results.Ok(new
        {
            success = true,
            merchantOrderId = merchantOrderID,
            amount = 100,
            response = new
            {
                state = response.State,
                redirectUrl = response.RedirectUrl,
                orderId = response.OrderId,
                expireAt = response.ExpireAt
            }
        });
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error creating payment");
        return Results.BadRequest(new
        {
            success = false,
            error = ex.Message,
            details = ex.ToString()
        });
    }
});

// Create SDK Order Endpoint
app.MapPost("/create-sdk-order", async () =>
{
    try
    {
        var redirectUrl = "https://www.merchant.com/redirect";
        var merchantOrderID = Guid.NewGuid().ToString();
         
        // Build SDK Order Request (following PhonePe documentation)
        var sdkOrderRequest = CreateSdkOrderRequest.StandardCheckoutBuilder()
                    .SetMerchantOrderId(merchantOrderID)
                    .SetAmount(100) // Amount in paise (100 paise = ₹1)
                    .SetRedirectUrl(redirectUrl)
                    .Build();
         
        // Call PhonePe CreateSdkOrder API
        CreateSdkOrderResponse response = await checkoutClient.CreateSdkOrder(sdkOrderRequest);
        
        // Log the response
        logger.LogInformation("CreateSDK Order Response:\n{Response}", JsonSerializer.Serialize(response, new JsonSerializerOptions { WriteIndented = true }));
         
        var token = response.Token;

        return Results.Ok(new
        {
            success = true,
            merchantOrderId = merchantOrderID,
            amount = 100,
            token = token,
            response = response
        });
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error creating SDK order");
        return Results.BadRequest(new
        {
            success = false,
            error = ex.Message,
            details = ex.ToString()
        });
    }
});

// Get Order Status Endpoint
app.MapGet("/order-status/{orderId}", async (string orderId) =>
{
    try
    {
        // Call PhonePe GetOrderStatus API (following PhonePe documentation)
        var response = await checkoutClient.GetOrderStatus(orderId, details: true);
        
        // Log the response
        logger.LogInformation("Order Status Response:\n{Response}", JsonSerializer.Serialize(response, new JsonSerializerOptions { WriteIndented = true }));

        return Results.Ok(new
        {
            success = true,
            orderId = orderId,
            response = response
        });
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error getting order status");
        return Results.BadRequest(new
        {
            success = false,
            orderId = orderId,
            error = ex.Message,
            details = ex.ToString()
        });
    }
});

// Initiate Refund Endpoint
app.MapPost("/initiate-refund", async (HttpContext context) =>
{
    try
    {
        using var reader = new StreamReader(context.Request.Body);
        var body = await reader.ReadToEndAsync();
        var requestData = JsonSerializer.Deserialize<JsonElement>(body);
        
        var originalMerchantOrderId = requestData.GetProperty("merchantOrderId").GetString() 
            ?? throw new InvalidOperationException("merchantOrderId is required");
        var amount = requestData.GetProperty("amount").GetInt64();
        
        var refundId = $"Refund_{DateTime.UtcNow:yyyyMMddHHmmssfff}";
        
        // Build Refund Request (following PhonePe documentation)
        var refundRequest = RefundRequest.Builder()
            .SetMerchantRefundId(refundId)
            .SetAmount(amount)
            .SetMerchantOrderId(originalMerchantOrderId)
            .Build();
        
        // Call PhonePe Refund API
        RefundResponse response = await checkoutClient.Refund(refundRequest);
        
        // Log the response
        logger.LogInformation("Refund Response:\n{Response}", JsonSerializer.Serialize(response, new JsonSerializerOptions { WriteIndented = true }));
        
        return Results.Ok(new
        {
            success = true,
            refundId = refundId,
            merchantOrderId = originalMerchantOrderId,
            amount = amount,
            response = response
        });
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error initiating refund");
        return Results.BadRequest(new
        {
            success = false,
            error = ex.Message,
            details = ex.ToString()
        });
    }
});

// Refund Status Request Endpoint
app.MapGet("/refund-status/{refundId}", async (string refundId) =>
{
    try
    {
        // Call PhonePe GetRefundStatus API (following PhonePe documentation)
        var response = await checkoutClient.GetRefundStatus(refundId);
        
        // Log the response
        logger.LogInformation("Refund Status Response:\n{Response}", JsonSerializer.Serialize(response, new JsonSerializerOptions { WriteIndented = true }));
        
        return Results.Ok(new
        {
            success = true,
            refundId = refundId,
            response = response
        });
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error getting refund status");
        return Results.BadRequest(new
        {
            success = false,
            refundId = refundId,
            error = ex.Message,
            details = ex.ToString()
        });
    }
});

// Webhook Handling Endpoint
app.MapPost("/webhook", async (HttpContext context) =>
{
    try
    {
        // Get authorization header from request
        string authorizationHeaderData = context.Request.Headers["X-VERIFY"].ToString();
        
        if (string.IsNullOrEmpty(authorizationHeaderData))
        {
            logger.LogWarning("Missing X-VERIFY header in webhook request");
            return Results.BadRequest(new { success = false, error = "Missing X-VERIFY header" });
        }
        
        // Read callback body as string
        using var reader = new StreamReader(context.Request.Body);
        var phonepeS2SCallbackResponseBodyString = await reader.ReadToEndAsync();
        
        // Get merchant credentials from configuration
        var usernameConfigured = app.Configuration["PhonePe:MerchantUsername"] ?? "default_username";
        var passwordConfigured = app.Configuration["PhonePe:MerchantPassword"] ?? "default_password";
        
        // Validate the callback (following PhonePe documentation)
        CallbackResponse callbackResponse = checkoutClient.ValidateCallback(
            usernameConfigured, 
            passwordConfigured, 
            authorizationHeaderData, 
            phonepeS2SCallbackResponseBodyString
        );
        
        // Extract order details from callback (using Payload property with capital P)
        var orderId = callbackResponse.Payload.OrderId;
        var state = callbackResponse.Payload.State;
        var merchantOrderId = callbackResponse.Payload.MerchantOrderId;
        var amount = callbackResponse.Payload.Amount;
        
        logger.LogInformation("Webhook received for Order ID: {OrderId}, State: {State}, Merchant Order ID: {MerchantOrderId}", 
            orderId, state, merchantOrderId);
        
        // Log full callback response
        logger.LogInformation("Callback Response:\n{Response}", 
            JsonSerializer.Serialize(callbackResponse, new JsonSerializerOptions { WriteIndented = true }));
        
        return Results.Ok(new
        {
            success = true,
            orderId = orderId,
            merchantOrderId = merchantOrderId,
            state = state,
            amount = amount,
            message = "Webhook processed successfully"
        });
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error processing webhook");
        return Results.BadRequest(new
        {
            success = false,
            error = ex.Message,
            details = ex.ToString()
        });
    }
});

app.Run();
